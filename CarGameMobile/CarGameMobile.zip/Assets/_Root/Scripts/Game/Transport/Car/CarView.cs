using UnityEngine;

namespace Game.Transport.Car
{
    internal class CarView : MonoBehaviour
    {

    }
}
