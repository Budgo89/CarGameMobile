using UnityEngine;

namespace Game.Transport.Boat
{
    internal class BoatView : MonoBehaviour
    {

    }
}
