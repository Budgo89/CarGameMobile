namespace Game
{
    internal enum TransportType
    {
        Car,
        Boat
    }
}
