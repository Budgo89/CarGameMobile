namespace Features.AbilitySystem.Abilities
{
    internal enum AbilityType
    {
        None,
        Gun,
        Jump
    }
}
