namespace Features.Shed.Upgrade
{
    internal enum UpgradeType
    {
        None,
        Speed,
        JumpHeight
    }
}
