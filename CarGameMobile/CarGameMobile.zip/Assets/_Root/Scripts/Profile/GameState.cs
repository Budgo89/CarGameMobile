namespace Profile
{
    internal enum GameState
    {
        None,
        Start,
        Settings,
        Shed,
        Game
    }
}
