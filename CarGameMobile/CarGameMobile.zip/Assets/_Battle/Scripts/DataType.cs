namespace BattleScripts
{
    internal enum DataType
    {
        Money,
        Health,
        Power
    }
}
