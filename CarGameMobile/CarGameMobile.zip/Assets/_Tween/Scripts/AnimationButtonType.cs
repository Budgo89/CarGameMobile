namespace Tween
{
    internal enum AnimationButtonType
    {
        ChangeRotation,
        ChangePosition
    }
}
