namespace Rewards
{
    internal enum RewardType
    {
        Wood,
        Diamond
    }
}