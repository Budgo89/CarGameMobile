﻿namespace Rewards
{
    public enum TimeType
    {
        Day,
        Week
    }
}