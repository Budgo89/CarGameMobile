﻿using UnityEngine;

public class ExampleUnityUpdate : MonoBehaviour {
    private int i;

    private void Update() {
        i++;
    }
}